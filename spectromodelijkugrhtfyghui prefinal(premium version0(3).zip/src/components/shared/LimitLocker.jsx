import React from 'react';

// ALL FEATURES PERMANENTLY UNLOCKED - This component does nothing
export default function LimitLocker() {
    return null;
}
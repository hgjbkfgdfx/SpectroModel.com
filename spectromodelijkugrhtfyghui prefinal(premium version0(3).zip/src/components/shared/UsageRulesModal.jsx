import React from 'react';

// ALL FEATURES UNLOCKED - Modal completely disabled
export default function UsageRulesModal({ featureName, isPaidFeature = false, userTier = 'free' }) {
  return null;
}